# Jikiki
## Comment installer et faire fonctionner l'application

1. Telecharger Node.js [ici](https://nodejs.org/en/)
2. Installer Node.
3. Telecharger ou cloner le repo
4. Dans le dossier Jikiki faire Shift+right click
5. Ouvrir une fênetre de commande // Open command Line//Open PowerShell
6. Entrez `node bdserver.js`
7. Si tout va bien, vous devriez voir server is listening on 8080
8. Ouvrez votre fureteur préféré a localhost:8080
9... Gardez la fenêtre de commande ouverte